function setup() {
    noCanvas();
    let r = floor(random(8)) + 0;
    let img = createImg(r + '.jpg' );
    img.size([1520], [670]);
    img.position([10], [70]);
}


let filename = [
    "11.jpg",
    "12.jpg ",
    "13.jpg ",
    "15.jpg ",
    "16.jpg ",
    "17.jpg " 
];

let imgs = document.getElementsByTagName('img');
for (imgElt of imgs) {
    let r = Math.floor(Math.random() * filename.length);
    let file = 'images/' + filename[r];
    let url = chrome.extension.getURL(file);
        imgElt.src = url;
        console.log(url);
}